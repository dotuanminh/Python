# AI Gardening problem - Capstone Project for the course Introduction to AI

## Installation
The module is queue which can be installed using pip.
It is recommended to first create a virtual environment by running the following command
in the directory of the project:

Linux/MacOS/Windows:
    $ python3 -m venv venv

Then activate the virtual environtment by running the following command:

Linux/MacOs:
    $ source venv/bin/activate

Windows:
    $ .\venv\Scripts\activate.bat 

Then install the modules using the following commands:

    $ pip install queuelib

It will automatically install all important libaries


// Some notes about the variables used
- R: The row size of the matrix
- C: The column size of the matrix
- matrix: the input matrix
- matrix_discover: the matrix the AI machine sees
- visited: check if a cell in a matrix is visited or not
- path: contains the cell the AI machine has to go to from beginning until it finishes its job
- state : This contains the direction of the AI machine heads after everytime it moves (It can head up,down,right left as we mention in the report)
- action: contains all the actions the AI machine needs to take (in chronological order)
- graph : the matrix the AI machine sees (matrix_discover) in dictionary type







// Some notes about the functions used

*Astar+DFS
-Init : This function initializes:
+ all the cells in the matrix is not visited at first
+ The matrix the AI see at first is full of -1 (Because the AI have not explored any cell yet)
+The first state of the AI machine at (0,0) is right (head towards (0,1))

-Input: This function takes the input from the file ’file.txt’ in the following order: 
//row_size column_size
//input the matrix here 

-heuristic:This is the heuristic function used to calculate heuristics for the A* search algorithms

-astar:  This function applies A* search algorithms, return the shortest path from a start node to the goal node.

-dfs :This function applies DFS algorithms to traverse through all the cells in the matrix

-movementActionAppend :This functions will receive a path and the current state the AI machine heads to find suitable actions to take.

- taskActionAppend :This function receives a coordinate of the cell in the matrix, determine what kind of cell it is to add the right actions to it.
 
-printMatrix :This function receives list and then print it in matrix-form

-printTotalStep : This function prints out the total step needed

-printPerceptSequenceAction : This function prints out all the percept sequence and actions 

-main : This function contains all the main things to do in the program

-executionTime : This function calculates the time taken to execute the program

*BFS+DFS :
- BFS : This function applies BFS algorithm to find the shortest path from a start node (i_s,j_s) to a goal node(i_e,j_e)

- updateGraph : This function will update the matrix the AI sees every time the AI machine explore a new cell in the matrix 

- The definition of other functions are similar to the same-name functions we have described in Astar+DFS 





