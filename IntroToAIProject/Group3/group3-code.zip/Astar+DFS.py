import time
R=int #initiate the row size
C=int #initiate the column size
matrix=[[int]] #state of each cell [i][j] in the garden
matrix_discover=[[int]]#This list defines the state of each cell seen by the AI machine. # Denote -1 if it is not yet discovered
#Denote 0:Scarecrow 1: Warehouse 3:Live Tree 4:Dead Tree  2:Newly planted seed
visited=[[bool]] #define that the cell is visited or not(initiate all to false at first)
path=[]
#Defines which direction the AI machine machine head: up, down, right, left
#At (0,0) it always head towards
state=[]
action=[]

def Init(R,C):
    global visited,matrix_discover,state
    visited = [[False] * C for i in range(R)]
    matrix_discover = [[-1] * C for i in range(R)]
    state = ['right']

def Input():
    global R,C,matrix
    cnt_line=-1
    file = open('file.txt','r')
    #print(file.read())
    R,C= file.readline().strip().split()
    R=int(R)
    C=int(C)
    matrix=[[-1]*C for i in range(R)]
    for lines in file.readlines()[0:R+1]:
        cnt_line = cnt_line + 1
        matrix[cnt_line] = lines.strip().split()
        matrix[cnt_line]= list(map(int,matrix[cnt_line]))


def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def astar(matrix, start, goal):
    moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]

    open_list = set()
    close_list = set()
    open_list.add(start)
    previous = {}
    gscore = {start: 0}
    fscore = {start: heuristic(start, goal)}

    comp = lambda i: fscore[i]
    while len(open_list) != 0:
        l=list(open_list)
        l.sort(key=comp)
        current = l[0]
        open_list.remove(current)
        if current == goal:
            path=[]
            while current in previous:
                path.append(current)
                current = previous[current]
            path.append(start)
            path.reverse()
            return path
        close_list.add(current)
        for i, j in moves:
            neighbor = current[0] + i, current[1] + j
            cost = gscore[current] + 1
            if 0 <= neighbor[0] < len(matrix) and 0 <= neighbor[1] < len(matrix[0]) and matrix[neighbor[0]][neighbor[1]] > 0:
                if neighbor in open_list:
                    if gscore[neighbor]<= cost:
                        continue
                elif neighbor in close_list:
                    if gscore[neighbor] <= cost:
                        continue
                    close_list.remove(neighbor)
                    open_list.add(neighbor)
                else:
                    open_list.add(neighbor)
                gscore[neighbor]=cost
                fscore[neighbor]=cost+heuristic(neighbor,goal)
                previous[neighbor]=current


    return False

def dfs(x,y):
    global path,matrix_discover,matrix,state,action
    matrix_discover[x][y] = matrix[x][y]
    size = len(action)
    if visited[x][y] == True:
        return
    visited[x][y] = True
    if matrix[x][y]==0:
        return
    if len(path)>=1:
        if abs(path[-1][0]-x+path[-1][1]-y) != 1:
            for item in astar(matrix_discover,(path[-1][0],path[-1][1]),(x,y))[1:-1]:
                path.append(item)
                movementActionAppend(path,state,action)

    path.append((x,y))
    movementActionAppend(path,state,action)
    taskActionAppend(matrix,x,y)
    print("Action: " + str(action[size:]))
    print("Percept sequence:")
    printMatrix(matrix_discover)
    print("Path: " + str(path))
    print("")
    move = [[0, 1], [1, 0], [-1, 0], [0, -1]]  # move we can conduct
    # x,y  x move[i][0] y move[i][1]  for i in range(0,4)
    for i in range(0, 4):
        m = int(x + move[i][0])
        n = int(y + move[i][1])
        if 0<= m <R and 0<= n <C and (bool(visited[m][n]) == False) :
            dfs(m,n)

def movementActionAppend(path,state,action):
    if len(path)<=1:
        return
    if state[-1] == 'up':
        if path[-1][1]-path[-2][1]==1:
            action.append('Right')
            action.append('Forward')
            state.append('right')
        elif path[-1][1]-path[-2][1]==-1:
            action.append('Left')
            action.append('Forward')
            state.append('left')
        elif path[-1][0] - path[-2][0] == 1:
            action.append('Right')
            action.append('Right')
            action.append('Forward')
            state.append('down')
        elif path[-1][0] - path[-2][0] == -1:
            action.append('Forward')
            state.append('up')

    elif state[-1] == 'down':
        if path[-1][1] - path[-2][1] == 1:
            action.append('Left')
            action.append('Forward')
            state.append('right')
        elif path[-1][1] - path[-2][1] == -1:
            action.append('Right')
            action.append('Forward')
            state.append('left')
        elif path[-1][0] - path[-2][0] == 1:
            action.append('Forward')
            state.append('down')
        elif path[-1][0] - path[-2][0] == -1:
            action.append('Right')
            action.append('Right')
            action.append('Forward')
            state.append('up')
    elif state[-1] == 'right':
        if path[-1][1] - path[-2][1] == 1:
            action.append('Forward')
            state.append('right')
        elif path[-1][1] - path[-2][1] == -1:
            action.append('Right')
            action.append('Right')
            action.append('Forward')
            state.append('left')
        elif path[-1][0] - path[-2][0] == 1:
            action.append('Right')
            action.append('Forward')
            state.append('down')
        elif path[-1][0] - path[-2][0] == -1:
            action.append('Left')
            action.append('Forward')
            state.append('up')
    elif state[-1] == 'left':
        if path[-1][1] - path[-2][1] == 1:
            action.append('Right')
            action.append('Right')
            action.append('Forward')
            state.append('right')
        elif path[-1][1] - path[-2][1] == -1:
            action.append('Forward')
            state.append('left')
        elif path[-1][0] - path[-2][0] == 1:
            action.append('Left')
            action.append('Forward')
            state.append('down')
        elif path[-1][0] - path[-2][0] == -1:
            action.append('Right')
            action.append('Forward')
            state.append('up')

def taskActionAppend(matrix,x,y):
    global action,path,state,matrix_discover
    if matrix[x][y]==2:
        action.append('Water')
    elif matrix[x][y]==3:
        action.append('Pick the fruit')
        for i in astar(matrix_discover, (x, y), (0, 0))[1:]:
            path.append(i)
            movementActionAppend(path, state, action)
        action.append('Bring fruit to WH')
    elif matrix[x][y]==4:
        action.append('Remove DT')
        for i in astar(matrix_discover,(x, y), (0, 0))[1:]:
            path.append(i)
            movementActionAppend(path, state, action)
        action.append('Bring DT to WH')
        for i in astar(matrix_discover, (0, 0), (x, y))[1:]:
            path.append(i)
            movementActionAppend(path, state, action)
        action.append('Plant and water')

def printMatrix(matrix):
    for i in range(len(matrix)):
        for j in range(len(matrix[0])):
            print(matrix[i][j], end=" ")
        print()

def printTotalStep(action):
    print("Total step is " + str(len(action)))

def printPerceptSequenceAction():
    global R,C
    #dfs
    for i in range(R):
        for j in range(C):
            dfs(i, j)

    # Print the last state of the matrix_discover
    for i in matrix_discover:
        if i == -1:
            i = 0
    print("Percept sequence:")
    printMatrix(matrix_discover)

def main():
    global R,C
    Input()
    Init(R, C)
    #print(astar(matrix, 6,7, 0, 0))
    #wait_timeout(astar(matrix,0,0,0,1))
    # print the percept sequence and the action it takes in every step
    printPerceptSequenceAction()
    # print total steps
    printTotalStep(action)

def executionTime():
    start_time = time.time()
    try:
        main()
    except:
        print("Can not find the path")
    #print the execution time
    print("--- %s seconds ---" % (time.time() - start_time))


executionTime()
