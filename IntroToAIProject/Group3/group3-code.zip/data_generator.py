import random
m = int(input('m = '))
n = int(input('n = '))
matrix=[]
for i in range(m):
    c=[]
    for j in range(n):
        if i == 0 and j == 0:
            c.append(1)
            continue
        a = random.randint(0, 4)
        while a == 1:
            a = random.randint(0, 4)
        c.append(a)
    print()
    matrix.append(c)
print(str(m) + ' ' + str(n))
for i in range(m):
    for j in range(n):
        print(matrix[i][j], end = ' ')
    print()

f = open('%sx%s(random).txt'%(m, n), 'w')
f.write(str(m) + ' ' + str(n) + '\n')
for i in range(m):
    for j in range(n):
        f.write(str(matrix[i][j]) + ' ')
    f.write('\n')
f.close()
